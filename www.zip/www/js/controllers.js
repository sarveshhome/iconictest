angular.module('app.controllers', [])
  
.controller('carltonLeisureCtrl', function($scope) {

})
 